from fastapi import APIRouter
from models.user import User
from config.db import conn
from schemas.user import users,userEntity
from bson.objectid import ObjectId


user = APIRouter()

@user.get('/')
async def get_all_users():
    return users(conn.local.user.find())

@user.get('/{id}')
async def get_user(id):
    return userEntity(conn.local.user.find_one({"_id":ObjectId(id)}))

@user.post('/')
async def post_user(user:User):
    conn.local.user.insert_one(dict(user))
    return users(conn.local.user.find())


@user.put('/{id}')
async def update_user(id,user:User):
    # if id not in conn.local.user.find():
    #     return "id not found"
    # else:
    conn.local.user.find_one_and_update({"_id":ObjectId(id)} , {"$set":dict(user)})
    return userEntity(conn.local.user.find_one({"_id":ObjectId(id)}))

@user.delete('/{id}')
async def delete_user(id):
    conn.local.user.find_one_and_delete({"_id":ObjectId(id)})
    return "User Deleted Successfully!!"

