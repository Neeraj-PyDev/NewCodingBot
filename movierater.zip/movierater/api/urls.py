from django.urls import path
from rest_framework import routers
from django.conf.urls import include
from .views import MovieViewSet , RatingViewSet , UserViewSet

router = routers.DefaultRouter()
router.register('Movies',MovieViewSet)
router.register('Ratings',RatingViewSet)
router.register('Users',UserViewSet)

urlpatterns = [
    path('' , include(router.urls)),

]
