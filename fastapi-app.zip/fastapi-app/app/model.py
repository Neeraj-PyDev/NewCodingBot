from pydantic import BaseModel,Field,EmailStr

class PostSchema(BaseModel):
    
    title:str = Field(default=None)
    content:str = Field(default=None)
    
    class Config:
        schema_extra={
            "post_demo":{
                "title":"some title about animals",
                "Content":"Some Content about animals"
            }
        }

class UserSchema(BaseModel):
    fullname : str = Field(default=None)
    email : EmailStr = Field(default = None)
    password : str = Field(default=None)
    
    class Config:
        the_schema = {
            "user_demo":{
                "name":"David",
                "email":'David123@tz.in',
                "password":"dvd123"
            }
        }

class UserLoginSchema(BaseModel):
    email : EmailStr = Field(default = None)
    password : str = Field(default=None)
    
    class Config:
        the_schema = {
            "user_demo":{
                "email":'David123@tz.in',
                "password":"dvd123"
            }
        }

# for printing user by id

def userEntity(item) -> dict:
    return {
        "id":str(item['_id']),
        "title":item['title'],
        "content":item['content']
    }
    
# for printing all users

def get_users(entity) -> list:
    return [userEntity(item) for item in entity]
