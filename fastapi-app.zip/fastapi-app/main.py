import uvicorn
from fastapi import FastAPI, Body, Depends
from app.model import PostSchema , UserSchema , UserLoginSchema , userEntity , get_users
from app.auth.jwt_handler import signJWT
from app.auth.jwt_bearer import jwtBearer
from app.db import conn
from bson import ObjectId

users = []

app = FastAPI()

#Testing
@app.get('/',tags=["test"])
def greet():
    return {"Hello":"World"}

#Get all posts
@app.get('/posts',tags=['GetUsers'])
async def get_all():
    return get_users(conn.animals.user.find())


#Get single post based on ID
@app.get('/posts{id}',tags=['UsersbyID'])
async def get_one_post(id):
    return userEntity(conn.animals.user.find_one({"_id":ObjectId(id)}))
     

#Post the new Element in Posts.
@app.post('/posts', dependencies = [Depends(jwtBearer())] , tags=['Create'])
async def create_post(schema:PostSchema):
    conn.animals.user.insert_one(schema.dict())
    return {
        "info":"Post Added Successfully"
    }

#Update Post Element
@app.put('/posts{id}',tags=['Update'])
async def update_post(id,schema:PostSchema):
    if id not in conn.animals.user.find():
        return "Id not found"
    conn.animals.user.find_one_and_update({"_id":ObjectId(id)} , {"$set":dict(schema)})
    return {"Status":"Post Updated Suceessfully"}
    #return userEntity(conn.animals.user.find_one({"_id":ObjectId(id)}))

#Delete Post Element
@app.delete('/posts{id}',tags=['Delete'])
async def delete_posts(id):
    if id not in conn.animals.user.find():
        return "Id not found"
    conn.animals.user.find_one_and_delete({"_id":ObjectId(id)})
    return {"Status":"Post deleted Successfully"}


# User Signup (create a new User)
@app.post('/user/signup',tags = ['user'])
def user_signup( user : UserSchema = Body(default = None)):
    users.append(user)
    return signJWT(user.email)

# Check User
def check_user(data : UserLoginSchema):
    for user in users:
        if user.email == data.email and user.password == data.password:
            return True
        return False

# USer Login
@app.post('/user/login',tags = ['user'])
def user_login(user : UserLoginSchema = Body(default = None)):
    if check_user(user):
        return signJWT(user.email)
    else:
        return {
            "Invalid login details"
        }
