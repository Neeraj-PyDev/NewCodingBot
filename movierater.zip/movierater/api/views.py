
from django.shortcuts import render
from django.contrib.auth.models import User
from rest_framework import viewsets , status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Movie,Rating
from .serializers import MovieSerilizer,RatingSerializer,UserSerializer
# Create your views here.

class MovieViewSet(viewsets.ModelViewSet):
    queryset = Movie.objects.all()
    serializer_class = MovieSerilizer

    @action(detail=True , methods=['POST']) #----to get the url   "/rate_movie"   based on id as pk 
    def rate_movie(self,request,pk=None):
        if 'star' in request.data:

            movie_name=Movie.objects.get(id=pk)
            star = request.data['star']
            user = User.objects.get(id=1)
            print('user' , user.username)

            try:
                rating = Rating.objects.get(movie = movie_name.id , user = user.id)
                rating.star = star
                rating.save()
            except:
                Rating.objects.create(user=user , movie=movie_name , star=star)
                

            response = {'message':'This is working.'}
            return Response(response,status=status.HTTP_200_OK)
        else:
            response = {'message':'You need star for rating.'}
            return Response(response,status=status.HTTP_400_BAD_REQUEST)



class RatingViewSet(viewsets.ModelViewSet):
    queryset = Rating.objects.all()
    serializer_class = RatingSerializer

    @action(detail=True , methods=['POST'])
    def box_office(self,request,pk=None):
        rating_star = request.data['star']
        
        if int(rating_star) <=3 :
            
            response = {'message':'This is not a good movie.'}
            return Response(response,status=status.HTTP_200_OK)


        else:
            response = {'message':'This is a good movie.'}
            return Response(response,status=status.HTTP_200_OK)



#-------------------------------------------------------


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
