from rest_framework import serializers
from .models import Movie, Rating
from django.contrib.auth.models import User


class MovieSerilizer(serializers.ModelSerializer):
    class Meta:
        model = Movie
        fields = ('id','title','description','no_of_ratings','avg_rating')

class RatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rating
        fields = ('id','star','user','movie')


#--------------------------------------------------------------------------

#User Specific

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','username','password')
        extra_kwargs = {'password':{'write_only':True , 'required':True}}

