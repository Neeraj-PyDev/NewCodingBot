from pymongo import MongoClient

conn = MongoClient('mongodb://localhost:27017/')
