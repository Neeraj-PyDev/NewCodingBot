
#This function we can only use when we pass id .
def userEntity(item) -> dict:

    return {
        "id":str(item['_id']),
        "name":item['name'],
        "email":item['email'],
        "password":item['password']
    }

#This function we can use anytime when we want to return users
def users(entity) -> list:
    return [userEntity(item) for item in entity]


